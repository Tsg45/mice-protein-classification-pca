# Final Assignment: Mice Protein Expression

ไฟล์ในโฟลเดอร์นี้ประกอบด้วยรายงานภาษาไทย, source code, ชุดข้อมูล CSV ที่แปลงจากไฟล์ต้นฉบับของ UCI, ตารางผลลัพธ์ และกราฟ

## วิธีรันใหม่
1. ติดตั้ง Python 3.10 ขึ้นไป
2. เปิด Terminal ในโฟลเดอร์นี้
3. ติดตั้งแพ็กเกจด้วย `python -m pip install -r requirements.txt`
4. รัน `python run_analysis.py`

สคริปต์อ่าน `Data_Cortex_Nuclear.csv` จากโฟลเดอร์เดียวกัน และสร้าง `metrics.csv`, `fold_metrics.csv`, `results.json` กับกราฟทั้งเจ็ดไฟล์ใน `figures/`.

## การอ้างอิงข้อมูล
Higuera, C., Gardiner, K. J., & Cios, K. J. (2015). Mice Protein Expression. UCI Machine Learning Repository. https://doi.org/10.24432/C50S3Z. ใบอนุญาต CC BY 4.0; กรุณาคงการอ้างอิงเมื่อเผยแพร่หรือส่งต่อข้อมูล

หน้า dataset: https://archive.ics.uci.edu/dataset/342/mice+protein+expression
