from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / 'Data_Cortex_Nuclear.csv'
FIG_DIR = ROOT / 'figures'
FIG_DIR.mkdir(exist_ok=True)
RANDOM_STATE = 42
N_SPLITS = 5
PCA_VARIANCE = 0.95

plt.rcParams.update({'figure.dpi': 140, 'savefig.dpi': 180, 'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})


def make_pipeline(model, use_pca=False):
    steps = [('imputer', SimpleImputer(strategy='median')), ('scaler', StandardScaler())]
    if use_pca:
        steps.append(('pca', PCA(n_components=PCA_VARIANCE, svd_solver='full')))
    steps.append(('model', model))
    return Pipeline(steps)


def main():
    df = pd.read_csv(DATA_PATH)
    target_col = 'class'
    metadata_cols = {'MouseID', 'Genotype', 'Treatment', 'Behavior', target_col}
    protein_cols = [c for c in df.columns if c not in metadata_cols]
    X = df[protein_cols].apply(pd.to_numeric, errors='coerce')
    y = df[target_col].astype(str)
    # MouseID values are measurement IDs such as 309_1...309_15; the prefix identifies the actual mouse.
    groups = df['MouseID'].astype(str).str.rsplit('_', n=1).str[0]
    classes = sorted(y.unique())
    cv = StratifiedGroupKFold(n_splits=N_SPLITS, shuffle=True, random_state=RANDOM_STATE)
    splits = list(cv.split(X, y, groups))

    models = {
        'SVM RBF': SVC(C=3.0, kernel='rbf', gamma='scale', class_weight='balanced'),
        'Random Forest': RandomForestClassifier(n_estimators=120, min_samples_leaf=1, class_weight='balanced_subsample', random_state=RANDOM_STATE, n_jobs=1),
    }
    results = []
    oof = {}
    fold_rows = []
    pca_components = []

    for model_name, model in models.items():
        for use_pca in (False, True):
            label = f'{model_name} | ' + ('PCA 95%' if use_pca else '77 features')
            pred = pd.Series(index=y.index, dtype='object')
            fold_scores = []
            for fold_no, (train_idx, test_idx) in enumerate(splits, start=1):
                estimator = make_pipeline(model, use_pca)
                estimator.fit(X.iloc[train_idx], y.iloc[train_idx])
                yhat = estimator.predict(X.iloc[test_idx])
                pred.iloc[test_idx] = yhat
                fold_result = {
                    'scenario': label,
                    'fold': fold_no,
                    'accuracy': accuracy_score(y.iloc[test_idx], yhat),
                    'macro_f1': f1_score(y.iloc[test_idx], yhat, average='macro'),
                    'balanced_accuracy': balanced_accuracy_score(y.iloc[test_idx], yhat),
                    'train_mice': groups.iloc[train_idx].nunique(),
                    'test_mice': groups.iloc[test_idx].nunique(),
                }
                if use_pca:
                    ncomp = int(estimator.named_steps['pca'].n_components_)
                    fold_result['pca_components'] = ncomp
                    pca_components.append(ncomp)
                else:
                    fold_result['pca_components'] = np.nan
                fold_scores.append(fold_result)
                fold_rows.append(fold_result)
            yhat_all = pred.loc[y.index].astype(str).to_numpy()
            oof[label] = yhat_all
            results.append({
                'scenario': label,
                'model': model_name,
                'pca': use_pca,
                'accuracy_oof': float(accuracy_score(y, yhat_all)),
                'macro_f1_oof': float(f1_score(y, yhat_all, average='macro')),
                'balanced_accuracy_oof': float(balanced_accuracy_score(y, yhat_all)),
                'accuracy_cv_mean': float(np.mean([r['accuracy'] for r in fold_scores])),
                'accuracy_cv_std': float(np.std([r['accuracy'] for r in fold_scores], ddof=1)),
                'macro_f1_cv_mean': float(np.mean([r['macro_f1'] for r in fold_scores])),
                'macro_f1_cv_std': float(np.std([r['macro_f1'] for r in fold_scores], ddof=1)),
                'balanced_accuracy_cv_mean': float(np.mean([r['balanced_accuracy'] for r in fold_scores])),
                'balanced_accuracy_cv_std': float(np.std([r['balanced_accuracy'] for r in fold_scores], ddof=1)),
            })

    metrics = pd.DataFrame(results).sort_values('macro_f1_cv_mean', ascending=False)
    metrics.to_csv(ROOT / 'metrics.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(fold_rows).to_csv(ROOT / 'fold_metrics.csv', index=False, encoding='utf-8-sig')

    # Exploratory descriptive PCA; all reported model metrics use fold-fitted preprocessing inside each pipeline.
    imputed = SimpleImputer(strategy='median').fit_transform(X)
    scaled = StandardScaler().fit_transform(imputed)
    pca_all = PCA(svd_solver='full').fit(scaled)
    cumvar = np.cumsum(pca_all.explained_variance_ratio_)
    descriptive_n95 = int(np.searchsorted(cumvar, PCA_VARIANCE) + 1)
    pca_2d = PCA(n_components=2, random_state=RANDOM_STATE).fit_transform(scaled)

    # Class balance.
    class_counts = y.value_counts().reindex(classes)
    fig, ax = plt.subplots(figsize=(9, 4.4))
    bars = ax.bar(class_counts.index, class_counts.values, color='#4979A8')
    ax.bar_label(bars, padding=3, fontsize=8)
    ax.set(title='Samples by experimental class', xlabel='Class', ylabel='Number of measurements')
    ax.tick_params(axis='x', rotation=28)
    ax.margins(y=0.14)
    fig.tight_layout(); fig.savefig(FIG_DIR / '01_class_distribution.png', bbox_inches='tight'); plt.close(fig)

    # Missing values.
    missing_rate = X.isna().mean().sort_values(ascending=False).head(12).sort_values()
    fig, ax = plt.subplots(figsize=(8.5, 5))
    ax.barh(missing_rate.index, missing_rate.values * 100, color='#D28A46')
    ax.set(title='Features with the highest missing-value rates', xlabel='Missing values (%)', ylabel='Protein feature')
    ax.grid(axis='x', alpha=.25); fig.tight_layout(); fig.savefig(FIG_DIR / '02_missing_values.png', bbox_inches='tight'); plt.close(fig)

    # Explained variance.
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(np.arange(1, len(cumvar)+1), cumvar, color='#4979A8', linewidth=2)
    ax.axhline(PCA_VARIANCE, color='#D28A46', linestyle='--', label='95% variance threshold')
    ax.axvline(descriptive_n95, color='#6D9B75', linestyle=':', label=f'{descriptive_n95} components')
    ax.set(title='Cumulative explained variance after standardization', xlabel='Number of principal components', ylabel='Cumulative explained variance')
    ax.set_ylim(0, 1.02); ax.grid(alpha=.2); ax.legend(frameon=False); fig.tight_layout(); fig.savefig(FIG_DIR / '03_pca_variance.png', bbox_inches='tight'); plt.close(fig)

    # PCA map (descriptive only).
    fig, ax = plt.subplots(figsize=(8.5, 6))
    cmap = plt.get_cmap('tab10')
    for i, cls in enumerate(classes):
        mask = y.to_numpy() == cls
        ax.scatter(pca_2d[mask, 0], pca_2d[mask, 1], s=16, alpha=.62, color=cmap(i), label=cls)
    ax.set(title='Exploratory PCA projection (first two components)', xlabel=f'PC1 ({pca_all.explained_variance_ratio_[0]*100:.1f}% variance)', ylabel=f'PC2 ({pca_all.explained_variance_ratio_[1]*100:.1f}% variance)')
    ax.legend(title='Class', bbox_to_anchor=(1.02, 1), loc='upper left', frameon=False, fontsize=8); ax.grid(alpha=.15); fig.tight_layout(); fig.savefig(FIG_DIR / '04_pca_scatter.png', bbox_inches='tight'); plt.close(fig)

    # Compare grouped CV scores.
    metric_labels = ['SVM RBF | 77 features','SVM RBF | PCA 95%','Random Forest | 77 features','Random Forest | PCA 95%']
    metric_df = metrics.set_index('scenario').reindex(metric_labels)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.8), sharey=True)
    for ax, col, title in zip(axes, ['macro_f1_cv_mean','accuracy_cv_mean'], ['Macro F1 by grouped fold','Accuracy by grouped fold']):
        vals = metric_df[col].to_numpy()
        stdcol = 'macro_f1_cv_std' if col.startswith('macro') else 'accuracy_cv_std'
        errs = metric_df[stdcol].to_numpy()
        bars = ax.bar(np.arange(4), vals, yerr=errs, capsize=4, color=['#4979A8','#79A5CC','#6D9B75','#96B997'])
        ax.set_title(title); ax.set_ylim(0,1); ax.set_xticks(np.arange(4), ['SVM\nraw','SVM\nPCA','RF\nraw','RF\nPCA']); ax.grid(axis='y',alpha=.2)
        for b,v in zip(bars,vals): ax.text(b.get_x()+b.get_width()/2, v+.018, f'{v:.3f}', ha='center', fontsize=8)
    axes[0].set_ylabel('Score (mean ± SD)'); fig.suptitle('Five-fold cross-validation grouped by mouse', y=1.02, fontsize=12)
    fig.tight_layout(); fig.savefig(FIG_DIR / '05_model_comparison.png', bbox_inches='tight'); plt.close(fig)

    best_label = metrics.iloc[0]['scenario']
    best_pred = oof[best_label]
    cm = confusion_matrix(y, best_pred, labels=classes, normalize='true')
    fig, ax = plt.subplots(figsize=(8.2, 6.7))
    im = ax.imshow(cm, cmap='Blues', vmin=0, vmax=1)
    ax.set_xticks(np.arange(len(classes)), classes, rotation=35, ha='right')
    ax.set_yticks(np.arange(len(classes)), classes)
    ax.set_xlabel('Predicted class'); ax.set_ylabel('True class'); ax.set_title(f'Row-normalized out-of-fold confusion matrix\n{best_label}')
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]): ax.text(j,i,f'{cm[i,j]:.2f}',ha='center',va='center',fontsize=7,color='white' if cm[i,j]>.58 else '#1d2a35')
    fig.colorbar(im, ax=ax, fraction=.046, pad=.04, label='Proportion within true class')
    fig.tight_layout(); fig.savefig(FIG_DIR / '06_confusion_matrix.png', bbox_inches='tight'); plt.close(fig)

    # Mean Random Forest importance across the five non-PCA fold models; descriptive, not causal.
    rf = models['Random Forest']
    importances = []
    for train_idx, test_idx in splits:
        est = make_pipeline(rf, False).fit(X.iloc[train_idx], y.iloc[train_idx])
        importances.append(est.named_steps['model'].feature_importances_)
    mean_imp = np.mean(importances, axis=0)
    top_idx = np.argsort(mean_imp)[::-1][:12]
    top_features = [{'feature': protein_cols[i], 'importance': float(mean_imp[i])} for i in top_idx]
    fig, ax = plt.subplots(figsize=(8.5, 5))
    order = top_idx[::-1]
    ax.barh([protein_cols[i] for i in order], mean_imp[order], color='#6D9B75')
    ax.set(title='Top Random Forest features (mean across folds)', xlabel='Mean impurity-based importance', ylabel='Protein feature')
    ax.grid(axis='x', alpha=.2); fig.tight_layout(); fig.savefig(FIG_DIR / '07_feature_importance.png', bbox_inches='tight'); plt.close(fig)

    summary = {
        'dataset': 'UCI Mice Protein Expression',
        'n_rows': int(len(df)), 'n_features': int(len(protein_cols)), 'n_classes': int(y.nunique()),
        'n_measurement_ids': int(df['MouseID'].nunique()), 'n_mice': int(groups.nunique()),
        'measurements_per_mouse': int(df.groupby(groups).size().median()),
        'missing_protein_cells': int(X.isna().sum().sum()),
        'missing_protein_rate': float(X.isna().to_numpy().mean()),
        'class_counts': {k:int(v) for k,v in class_counts.items()},
        'pca_95_components_descriptive': descriptive_n95,
        'pca_95_components_cv_mean': float(np.mean(pca_components)),
        'pca_95_components_cv_min': int(np.min(pca_components)),
        'pca_95_components_cv_max': int(np.max(pca_components)),
        'best_scenario': best_label,
        'best_oof_classification_report': classification_report(y, best_pred, output_dict=True, zero_division=0),
        'metrics': metrics.to_dict(orient='records'),
        'top_random_forest_features': top_features,
        'folds': [{'fold':i,'train_mice':int(groups.iloc[tr].nunique()),'test_mice':int(groups.iloc[te].nunique()),'train_samples':len(tr),'test_samples':len(te)} for i,(tr,te) in enumerate(splits,1)],
    }
    (ROOT / 'results.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:summary[k] for k in ['n_rows','n_features','n_classes','n_mice','missing_protein_cells','missing_protein_rate','pca_95_components_cv_mean','pca_95_components_cv_min','pca_95_components_cv_max','best_scenario','metrics','top_random_forest_features']}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()


